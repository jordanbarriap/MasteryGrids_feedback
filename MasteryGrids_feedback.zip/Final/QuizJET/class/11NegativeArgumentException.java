
public class NegativeArgumentException extends IllegalArgumentException {

   public NegativeArgumentException() {
      super();
   }

   public NegativeArgumentException(String arg0) {
      super(arg0);
   }
	
}
