
public interface Mechanism {
	
	int reportProblems();
	
	void getFixed();	

}
