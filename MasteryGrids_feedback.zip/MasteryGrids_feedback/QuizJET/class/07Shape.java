public interface Shape{

  public boolean contains(double x, double y);

}
